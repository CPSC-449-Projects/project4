# Members: Quang Nguyen, Vinh Tran
# CPSC 449
# Project 4: Asynchronous Processing

import configparser
import logging.config
import requests
import redis
import sqlite_utils
import greenstalk
import json
import smtplib
from smtplib import SMTPException

cfg = configparser.ConfigParser()
cfg.read("./etc/like_mq.ini")
host = cfg["host"]["localhost"]
mq_address = (host, cfg["mq"]["port"])
email_port = cfg["email"]["port"]
postdb = cfg["sqlite"]["dbfile"]
redisdb = redis.Redis(host="localhost", port="6379")
address = (host, cfg["mq"]["port"])

# Initializing the sender and receiver email
sender = cfg["sender"]["email"]
receiver = cfg["sender"]["email"]

with greenstalk.Client(mq_address, encoding='utf-8', watch='likeMQ') as client:
    while True:
        # Getting the username and the post id
        job = client.reserve()
        job_body = json.loads(job.body)

        try:
                # Testing if the post is valid
                post = sqlite_utils.Database(postdb)["post"].get(job_body["post_id"])
        except sqlite_utils.db.NotFoundError:
                # Removing the invalid post
                # Retrieving user's email

                try:
                    r = requests.get(f'{cfg["registry"]["URL"]}/likes')
                    like_url = r.json()

                    payload = {'username': job_body["username"], 'post_id': job_body["post_id"]}
                    r = requests.post(like_url[0]+'/delete-post/', data = payload)

                    r = requests.get(f'http://127.0.0.1/users/{job_body["username"]}')
                    replies = r.json()
                    receiver = replies["user"]["email_address"]
                except requests.ConnectionError:
                    client.bury(job)

                # Constructing the email
                message = "From: " + sender + "\nTo: " + receiver + "\nSubject: Invalid Like" + "\nThe post that you liked is invalid because it is not in the database."

                # Trying to send the email
                try:
                   smtpObj = smtplib.SMTP(host, email_port)
                   smtpObj.sendmail(sender, receiver, message)
                except SMTPException:
                    client.bury(job)

        # Deleting the job
        client.delete(job)
